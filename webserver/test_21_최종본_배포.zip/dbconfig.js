module.exports = {
    user          :"jwuk",
    password      : "1234",
    connectString : "localhost:1521/xe",
};