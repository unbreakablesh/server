module.exports = {
    user          :"ljwTest",
    password      : "1111",
    connectString : "localhost:1521/xe",
};